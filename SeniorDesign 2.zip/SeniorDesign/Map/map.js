//This example creates a 2-pixel-wide red polyline showing the path of
// the first trans-Pacific flight between Oakland, CA, and Brisbane,
// Australia which was made by Charles Kingsford Smith.

var lat;
var pathLat = 0;
var lng;
var pathLng = 0;
var coordinates;
var arrLength;
var txt = '';
var i;
var n = 0;
var m = 0;

var rawGPS = new XMLHttpRequest();
rawGPS.open("GET", "https://raw.githubusercontent.com/Dalke320/RoverDesign/master/GPSdata", true);
rawGPS.send();
rawGPS.onreadystatechange = function(){
    if(rawGPS.status == 200 && rawGPS.readyState == 4){
        txt = rawGPS.responseText;
    }
        coordinates = txt.split(',');

        arrLength = coordinates.length;

        for(i=0; i <= arrLength; i++) {

            coordinates[i] = parseFloat(coordinates[i]);
        }

        lat = coordinates[0];

        lng = coordinates[1];

       //loop to generate latitude values for the path of the rover
        for(i = 0; i <= arrLength; i += 2) {
            pathLat[n] = coordinates[i];
            n++;
            console.log(pathLat[n]);    
        }
  
         //loop to generate longitude values for the path of the rover
        for(i = 1; i <= arrLength; i += 2) {
            pathLng[m] = coordinates[i];
            m++;
            console.log(pathLng[m]);  
        }
}



//var x,y,w,z;

/*function createVector(x, w, y,z) {
    this.x = "lat: "
    this.y = "lng: "
    this.w = lat 
    this.z = lng
};*/


function initMap() {


 let myLatLng = {lat, lng};

 console.log("Lat: ", lat, ", Lng: ", lng)



  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 24,
    center: myLatLng,
    mapTypeId: 'satellite'
  });
  
  /*//loop to generate latitude values for the path of the rover
  for(i = 0; i <= arrLength; i += 2) {
    pathLat[n] = parseFloat(coordinates[i])
    n++;
  }
  
  //loop to generate longitude values for the path of the rover
  for(i = 1; i <= arrLength; i += 2) {
    pathLng[n] = parseFloat(coordinates[i])
    n++;
  }*/

  var flightPlanCoordinates = [
    
    
  ];
  
  
  var flightPath = new google.maps.Polyline({
    path: flightPlanCoordinates,
    geodesic: true,
    strokeColor: 'green',
    strokeOpacity: .8,
    strokeWeight: 5
  });
  
  
          
  flightPath.setMap(map);
  
          var flightPlan = [
    {lat: 50.000, lng: 110.111},
    {lat: 50.423, lng: 120.012}
  ];
  
  
  var flight = new google.maps.Polyline({
    path: flightPlan,
    geodesic: true,
    strokeColor: 'purple',
    strokeOpacity: .8,
    strokeWeight: 5
  });
  
  


var marker = new google.maps.Marker({
position: myLatLng,
map: map,
title: 'SIU-C Rover'
});

  
  flight.setMap(map);
}

